TODO:

Create tests for the controller and for the service (angularjs.org application example was used).
Mock $httpBackend for the service test.

TO RUN:

1. In root folder run 'npm i node-static' using cmd console
2. In root folder run 'node server.js'
3. In browser open localhost:8000
4. To run tests open JasmineTestRunner.hmtl