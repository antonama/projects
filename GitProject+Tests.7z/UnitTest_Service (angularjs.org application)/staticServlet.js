var DEBUG_MODE = false;

var fs = require('fs');

function StaticServlet() {
}

StaticServlet.MimeMap = {
    'txt': 'text/plain',
    'html': 'text/html',
    'aspx': 'text/html',
    'cshtml': 'text/html',
    'css': 'text/css',
    'xml': 'application/xml',
    'json': 'application/json',
    'js': 'application/javascript',
    'jpg': 'image/jpeg',
    'jpeg': 'image/jpeg',
    'gif': 'image/gif',
    'png': 'image/png',
    'svg': 'image/svg+xml'
};

StaticServlet.prototype.handleRequest = function (req, res) {
    var self = this;
    var path = ('./' + req.url.pathname).replace('//', '/').replace(/%(..)/g, function (match, hex) {
        return String.fromCharCode(parseInt(hex, 16));
    });
    var parts = path.split('/');
    if (parts[parts.length - 1].charAt(0) === '.')  {
        return self.sendForbidden_(req, res, path);
    }

    if (DEBUG_MODE && req.url.query["module"]) {
        return self.sendDebugJsFile_(req, res, path, req.url.query["module"]);
    } else {
        fs.stat(path, function (err, stat) {
            if (err)
                return self.sendMissing_(req, res, path);
            if (stat.isDirectory())
                return self.sendDirectory_(req, res, path);
            return self.sendFile_(req, res, path);
        });
    }
};

StaticServlet.prototype.sendForbidden_ = function (req, res, path) {
    path = path.substring(1);
    res.writeHead(403, {
        'Content-Type': 'text/html'
    });
    res.write('<!doctype html>\n');
    res.write('<title>403 Forbidden</title>\n');
    res.write('<h1>Forbidden</h1>');
    res.write(
        '<p>You do not have permission to access ' +
            escapeHtml(path) + ' on this server.</p>'
    );
    res.end();
    console.log('403 Forbidden: ' + path);
};

StaticServlet.prototype.sendDebugJsFile_ = function (req, res, path, modul) {
    var self = this;
    res.writeHead(200, {
        'Content-Type': StaticServlet.MimeMap[path.split('.').pop()] || 'text/plain',
        'Access-Control-Allow-Origin': "*"
    });
    if (req.method === 'HEAD') {
        res.end();
    } else {

        var files = [];

        var writeFile = function(file) {
            if (files.indexOf(file) < 0) {
                files.push(file);
                var f = file.replace(/\\/g, "/");
                var paths = fspath.relative(process.cwd(), f).replace(/\\/g, "/");
                res.write("document.write('<script type=\"text/javascript\" src=\""+
                    "/" +paths+
                    "\"></script>');\n");

            }
        };

        var writeModuleFiles = function(mod, byCombine) {
            var resolved = {};

            if (resolved[mod.name]) {
                return;
            } else {
                resolved[mod.name] = true;
            }

            if (mod.dependencies && mod.dependencies.combine) {
                for (var i = 0; i < mod.dependencies.combine.length; i++) {
                    writeModuleFiles(mod.dependencies.combine[i], true);
                }
            }


            if (byCombine && mod.dependencies && mod.dependencies.provided) {
                for (var i = 0; i < mod.dependencies.provided.length; i++) {
                    writeModuleFiles(mod.dependencies.provided[i], byCombine);
                }
            }

            if (mod.dependencies && mod.dependencies.compile) {
                for (var i = 0; i < mod.dependencies.compile.length; i++) {
                    writeModuleFiles(mod.dependencies.compile[i], byCombine);
                }
            }
            if (mod.scripts.src) {
                for(var j = 0; j < mod.scripts.src.length; j++) {
                     writeFile(mod.scripts.src[j]);
                }
            }
        };
        modules = builder.modules.find(modulesPaths);
        var mainModule = modules[modul];
        if (mainModule) {
            if (mainModule.scripts && mainModule.scripts.entire) {
                for(var j = 0; j < mainModule.scripts.entire.length; j++) {
                    writeFile(mainModule.scripts.entire[j]);
                }
            }
            writeModuleFiles(mainModule);
        } else {
            console.error("Module " + modul + " not found");
        }

        res.end();
    }
};

StaticServlet.prototype.sendFile_ = function (req, res, path) {
    var self = this;
    try {

        var headers = {
            'Content-Type': StaticServlet.MimeMap[path.split('.').pop()] || 'text/plain',
            'Access-Control-Allow-Origin': "*"
        };

        if (fs.existsSync(path)) {
            headers['Last-Modified'] = fs.statSync(path).mtime.toUTCString();
        }
        res.writeHead(200, headers);
        if (req.method === 'HEAD') {
            res.end();
        } else {
            var file = fs.createReadStream(path);
            file.on('data', res.write.bind(res));
            file.on('close', function () {
                res.end();
            });
            file.on('error', function (error) {
                self.sendError_(req, res, error);
            });
        }
    } catch(e) {
        console.log(e);
    }
};

StaticServlet.prototype.sendDirectory_ = function (req, res, path) {
    var self = this;
    if (path.match(/[^\/]$/)) {
        req.url.pathname += '/';
        var redirectUrl = url.format(url.parse(url.format(req.url)));
        return self.sendRedirect_(req, res, redirectUrl);
    }
    fs.readdir(path, function (err, files) {
        if (err)
            return self.sendError_(req, res, error);

        if (!files.length)
            return self.writeDirectoryIndex_(req, res, path, []);

        var remaining = files.length;
        files.forEach(function (fileName, index) {
            fs.stat(path + '/' + fileName, function (err, stat) {
                if (err)
                    return self.sendError_(req, res, err);
                if (stat.isDirectory()) {
                    files[index] = fileName + '/';
                }
                if (!(--remaining))
                    return self.writeDirectoryIndex_(req, res, path, files);
            });
        });
    });
};

StaticServlet.prototype.sendMissing_ = function (req, res, path) {
    path = path.substring(1);
    res.writeHead(404, {
        'Content-Type': 'text/html'
    });
    res.write('<!doctype html>\n');
    res.write('<title>404 Not Found</title>\n');
    res.write('<h1>Not Found</h1>');
    res.write(
        '<p>The requested URL ' +
            escapeHtml(path) +
            ' was not found on this server.</p>'
    );
    res.end();
    console.log('404 Not Found: ' + path);
};

  
StaticServlet.prototype.sendError_ = function (req, res, error) {
    res.writeHead(500, {
        'Content-Type': 'text/html'
    });
    res.write('<!doctype html>\n');
    res.write('<title>Internal Server Error</title>\n');
    res.write('<h1>Internal Server Error</h1>');
    res.write('<pre>' + escapeHtml(error) + '</pre>');
    console.log('500 Internal Server Error');
    console.log(error);
};

StaticServlet.prototype.writeDirectoryIndex_ = function (req, res, path, files) {
    path = path.substring(1);
    res.writeHead(200, {
        'Content-Type': 'text/html'
    });
    if (req.method === 'HEAD') {
        res.end();
        return;
    }
    res.write('<!doctype html>\n');
    res.write('<title>' + escapeHtml(path) + '</title>\n');
    res.write('<style>\n');
    res.write('  ol { list-style-type: none; font-size: 1.2em; }\n');
    res.write('</style>\n');
    res.write('<h1>Directory: ' + escapeHtml(path) + '</h1>');
    res.write('<ol>');
    files.forEach(function (fileName) {
        if (fileName.charAt(0) !== '.') {
            res.write('<li><a href="' +
                escapeHtml(fileName) + '">' +
                escapeHtml(fileName) + '</a></li>');
        }
    });
    res.write('</ol>');
    res.end();
};

function escapeHtml(value) {
    return value.toString().
        replace('<', '&lt;').
        replace('>', '&gt;').
        replace('"', '&quot;');
}

exports.StaticServlet = StaticServlet;